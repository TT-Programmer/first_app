$(document).ready(function(){
  $("#micropost_edit_submit").click(function(){
  	alert("aaa")
  });
}
